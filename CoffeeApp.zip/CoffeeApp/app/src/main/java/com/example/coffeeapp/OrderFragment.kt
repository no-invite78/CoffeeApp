package com.example.coffeeapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment

class OrderFragment : Fragment() {

    private lateinit var tvPrice: TextView
    private lateinit var tvDeliveryFee: TextView
    private lateinit var tvWalletBalance: TextView
    private lateinit var tvQuantity: TextView
    private lateinit var btnOrder: Button
    private lateinit var btnPlus: Button
    private lateinit var btnMinus: Button

    private var quantity = 1
    private val unitPrice = 4.53

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_order, container, false)

        // Bind views
        tvPrice = view.findViewById(R.id.tvPrice)
        tvDeliveryFee = view.findViewById(R.id.tvDeliveryFee)
        tvWalletBalance = view.findViewById(R.id.tvWalletBalance)
        tvQuantity = view.findViewById(R.id.tvQuantity)
        btnOrder = view.findViewById(R.id.btnOrder)
        btnPlus = view.findViewById(R.id.btnPlus)
        btnMinus = view.findViewById(R.id.btnMinus)

        // Setup initial values
        updatePrice()

        // Quantity control
        btnPlus.setOnClickListener {
            quantity++
            updatePrice()
        }

        btnMinus.setOnClickListener {
            if (quantity > 1) {
                quantity--
                updatePrice()
            }
        }

        btnOrder.setOnClickListener {
            Toast.makeText(requireContext(), "Order placed!", Toast.LENGTH_SHORT).show()
        }

        return view
    }

    private fun updatePrice() {
        tvQuantity.text = quantity.toString()
        val total = unitPrice * quantity
        tvPrice.text = "Price: $%.2f".format(total)
    }
}
